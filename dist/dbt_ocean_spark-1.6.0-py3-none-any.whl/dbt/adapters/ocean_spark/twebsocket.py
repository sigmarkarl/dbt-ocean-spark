from thrift.transport.TTransport import TTransportBase
from websockets.sync.client import connect

class TWebSocket(TTransportBase):
    """Base class for Thrift transport layer."""

    def __init__(self, url, token, cert_reqs):
        self.url = url
        self.token = token
        self.cert_reqs = cert_reqs
        self.opened = False

    def isOpen(self):
        return self.opened

    def open(self):
        self.opened = True
        self.ws = connect(self.url,
              subprotocols=None,
              additional_headers={"Authorization": f"Bearer {self.token}"})

    def close(self):
        self.ws.close()

    def read(self, sz):
        return self.ws.recv(sz)

    def readAll(self, sz):
        buff = b''
        have = 0
        while (have < sz):
            chunk = self.read(sz - have)
            chunkLen = len(chunk)
            have += chunkLen
            buff += chunk

            if chunkLen == 0:
                raise EOFError()
        return buff

    def write(self, buf):
        self.ws.send(buf)

    def flush(self):
        pass