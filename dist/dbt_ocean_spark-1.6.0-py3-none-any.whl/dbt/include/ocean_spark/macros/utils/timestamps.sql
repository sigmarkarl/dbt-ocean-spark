{% macro ocean_spark__current_timestamp() -%}
    current_timestamp()
{%- endmacro %}
